"""Prepara la copia del juego dentro del APK: expone el estado y carga el panel de admin."""
import re
import sys

game = sys.argv[1]

# 1) Exponer el espacio de nombres del juego como window.__PS
p = game + '/js/app.min.js'
s = open(p, encoding='utf-8').read()
s, n = re.subn(r"var (_0x[0-9a-f]+)=\{'BUILT':", r"var \1=window.__PS={'BUILT':", s, count=1)
if n != 1:
    sys.exit('No se pudo exponer el estado del juego (app.min.js cambió).')
open(p, 'w', encoding='utf-8').write(s)

# 2) Cargar admin.js después del juego
p = game + '/index.html'
s = open(p, encoding='utf-8').read()
if '</body>' not in s:
    sys.exit('index.html no tiene </body>.')
s = s.replace('</body>', '<script defer src="admin.js"></script></body>', 1)
open(p, 'w', encoding='utf-8').write(s)
print('Parche de admin aplicado.')
