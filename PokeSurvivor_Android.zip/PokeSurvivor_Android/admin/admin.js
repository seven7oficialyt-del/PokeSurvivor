/* Panel de admin de PokéSurvivor (solo para el APK personal, sin conexión).
   Botón ⚙ abajo a la izquierda: da Pokémonedas, tickets y caramelos. */
(function () {
  'use strict';

  var FIELDS = [
    { k: 'coins', label: 'Pokémonedas', max: 1e12 },
    { k: 't1', label: 'Tickets ×1', max: 1e12 },
    { k: 't10', label: 'Tickets ×10', max: 1e12 },
    { k: 'candy', label: 'Caramelos', max: 999 }
  ];

  function ps() { return window.__PS || null; }
  function save() { var p = ps(); return p && p.DB ? p.DB.save : null; }

  function getVal(k) {
    var s = save();
    if (!s) return null;
    if (k === 'coins') return Number(s.coins) || 0;
    if (k === 't1' || k === 't10') return Number(s.tickets && s.tickets[k]) || 0;
    if (k === 'candy') return Number(s.bag && s.bag.candy) || 0;
    return 0;
  }

  function setVal(k, v) {
    var s = save();
    if (k === 'coins') { s.coins = v; return; }
    if (k === 't1' || k === 't10') { s.tickets = s.tickets || {}; s.tickets[k] = v; return; }
    if (k === 'candy') {
      s.bag = s.bag || {};
      if (v > 0) s.bag.candy = v; else delete s.bag.candy;
    }
  }

  function fmt(n) { return Math.floor(n).toLocaleString('es-ES'); }

  var style = document.createElement('style');
  style.textContent =
    '#psa-btn{position:fixed;left:calc(8px + env(safe-area-inset-left,0px));bottom:calc(8px + env(safe-area-inset-bottom,0px));' +
    'width:36px;height:36px;border-radius:50%;border:2px solid #ffd84a;background:rgba(10,20,48,.75);color:#ffd84a;' +
    'font:20px/30px system-ui,sans-serif;text-align:center;padding:0;z-index:2147483000;opacity:.55}' +
    '#psa-btn:active{opacity:1}' +
    '#psa-box{position:fixed;inset:0;z-index:2147483001;display:none;align-items:center;justify-content:center;' +
    'background:rgba(0,0,0,.6);font:14px/1.3 system-ui,sans-serif;color:#fff}' +
    '#psa-box.on{display:flex}' +
    '#psa-card{background:#0a1430;border:2px solid #ffd84a;border-radius:12px;padding:12px 14px;max-width:92vw;max-height:94vh;overflow:auto}' +
    '#psa-card h3{margin:0 0 8px;font-size:16px;color:#ffd84a}' +
    '.psa-row{display:flex;align-items:center;gap:6px;margin:6px 0}' +
    '.psa-row .n{width:104px}.psa-row .c{width:112px;text-align:right;color:#9fd}' +
    '.psa-row input{width:110px;padding:6px;border-radius:6px;border:1px solid #567;background:#122;color:#fff;font-size:15px}' +
    '.psa-row button,#psa-foot button{padding:7px 10px;border-radius:6px;border:1px solid #ffd84a;background:#1b2a5a;color:#ffd84a;font-size:14px}' +
    '#psa-msg{min-height:18px;margin-top:6px;color:#9fd}' +
    '#psa-foot{display:flex;gap:8px;margin-top:8px;justify-content:flex-end}';
  document.head.appendChild(style);

  var btn = document.createElement('button');
  btn.id = 'psa-btn';
  btn.type = 'button';
  btn.textContent = '⚙';
  btn.setAttribute('aria-label', 'Admin');

  var box = document.createElement('div');
  box.id = 'psa-box';
  var card = document.createElement('div');
  card.id = 'psa-card';
  var h = document.createElement('h3');
  h.textContent = 'Admin';
  card.appendChild(h);

  var msg = document.createElement('div');
  msg.id = 'psa-msg';
  var cur = {};
  var inputs = {};

  function say(t) { msg.textContent = t; }

  function refresh() {
    FIELDS.forEach(function (f) {
      var v = getVal(f.k);
      cur[f.k].textContent = v === null ? '—' : fmt(v);
    });
  }

  function apply(f, add) {
    if (!save()) { say('Entra primero a una cuenta (no como invitado).'); return; }
    var n = Math.floor(Number(inputs[f.k].value));
    if (!isFinite(n) || n < 0) { say('Escribe un número válido (0 o más).'); return; }
    var base = add ? getVal(f.k) : 0;
    var next = Math.min(f.max, base + n);
    setVal(f.k, next);
    var ok = false;
    try { ok = ps().DB.commit(); } catch (e) { ok = false; }
    refresh();
    say(ok ? f.label + ': ' + fmt(next) + ' ✔' : 'No se pudo guardar: entra con una cuenta, no como invitado.');
  }

  FIELDS.forEach(function (f) {
    var row = document.createElement('div');
    row.className = 'psa-row';
    var name = document.createElement('span');
    name.className = 'n';
    name.textContent = f.label;
    var c = document.createElement('span');
    c.className = 'c';
    cur[f.k] = c;
    var inp = document.createElement('input');
    inp.type = 'number';
    inp.inputMode = 'numeric';
    inp.min = '0';
    inp.placeholder = 'cantidad';
    inputs[f.k] = inp;
    var add = document.createElement('button');
    add.type = 'button';
    add.textContent = 'Sumar';
    add.onclick = function () { apply(f, true); };
    var set = document.createElement('button');
    set.type = 'button';
    set.textContent = 'Fijar';
    set.onclick = function () { apply(f, false); };
    row.appendChild(name); row.appendChild(c); row.appendChild(inp); row.appendChild(add); row.appendChild(set);
    card.appendChild(row);
  });

  card.appendChild(msg);
  var foot = document.createElement('div');
  foot.id = 'psa-foot';
  var reload = document.createElement('button');
  reload.type = 'button';
  reload.textContent = 'Recargar juego';
  reload.onclick = function () { location.reload(); };
  var close = document.createElement('button');
  close.type = 'button';
  close.textContent = 'Cerrar';
  close.onclick = function () { box.classList.remove('on'); };
  foot.appendChild(reload); foot.appendChild(close);
  card.appendChild(foot);
  box.appendChild(card);

  // Que los toques sobre el panel no lleguen al juego.
  ['touchstart', 'touchmove', 'pointerdown', 'mousedown', 'click', 'keydown'].forEach(function (ev) {
    btn.addEventListener(ev, function (e) { e.stopPropagation(); });
    box.addEventListener(ev, function (e) { e.stopPropagation(); });
  });

  btn.onclick = function () {
    say('');
    refresh();
    box.classList.add('on');
  };

  document.body.appendChild(btn);
  document.body.appendChild(box);
})();
